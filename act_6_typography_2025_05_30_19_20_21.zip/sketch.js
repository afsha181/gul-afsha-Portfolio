let y;
let speed = 3;
let direction = 1;
let hueVal = 0;

function setup() {
  createCanvas(800, 300);
  textSize(100);
  textAlign(CENTER, CENTER);
  colorMode(HSB, 360, 100, 100);
  y = height / 2;
}

function draw() {
  background(0, 0, 100); // White background

  // Update color hue
  hueVal = (hueVal + 1) % 360;

  // Set fill color with changing hue
  fill(hueVal, 80, 80);
  noStroke();

  // Draw text
  text("Gul Afsha", width / 2, y);

  // Update y position for bouncing effect
  y += speed * direction;

  // Reverse direction when reaching top or bottom
  if (y > height - 60 || y < 60) {
    direction *= -1;
  }
}
