let trail = [];
let lastMouseX, lastMouseY;
let lastMoveTime;
let pauseDuration = 500; // Pause after 500ms of no movement

function setup() {
  createCanvas(800, 600);
  noCursor();
  lastMouseX = mouseX;
  lastMouseY = mouseY;
  lastMoveTime = millis();
}

function draw() {
  background(255, 255, 255, 50);

  // Detect mouse movement
  if (mouseX !== lastMouseX || mouseY !== lastMouseY) {
    lastMoveTime = millis();
    lastMouseX = mouseX;
    lastMouseY = mouseY;

    // Add mouse position to trail
    trail.push({ x: mouseX, y: mouseY });
    if (trail.length > 50) {
      trail.shift();
    }
  }

  // Only draw trail if movement was recent
  if (millis() - lastMoveTime < pauseDuration) {
    noStroke();
    for (let i = 0; i < trail.length; i++) {
      let pos = trail[i];
      let alpha = map(i, 0, trail.length, 50, 255);
      let size = map(i, 0, trail.length, 5, 20);
      fill(150, 100, 255, alpha);
      ellipse(pos.x, pos.y, size);
    }
  }
}

